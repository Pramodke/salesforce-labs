import { LightningElement, api } from 'lwc';

export default class StudentResultCard extends LightningElement {
    @api rollNo;
    @api firstName;
    @api lastName;
    @api email;
    @api phone;
    @api branch;
    @api year;
    @api semester;
    @api sgpa;
    @api cgpa;
    @api result;
    @api backlogs;

    get fullName() {
        return `${this.firstName || ''} ${this.lastName || ''}`.trim();
    }
    get isPass() {
        return (this.result || '').toUpperCase() === 'PASS';
    }
    get badgeClass() {
        return this.isPass ? 'scard-badge pass' : 'scard-badge fail';
    }
}
