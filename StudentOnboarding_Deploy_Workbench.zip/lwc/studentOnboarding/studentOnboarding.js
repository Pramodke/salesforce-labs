import { LightningElement, api } from 'lwc';
import submitApplication from '@salesforce/apex/OnboardingController.submitApplication';

const ALLOWED = ['pdf', 'jpg', 'jpeg', 'png'];
const MAX_MB = 5;

export default class StudentOnboarding extends LightningElement {
    @api fullPageUrl = '';

    sscFiles = [];
    hscFiles = [];
    latitude = null;
    longitude = null;
    error = '';
    submitting = false;
    loading = true;
    done = false;

    connectedCallback() {
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(
                (pos) => { this.latitude = pos.coords.latitude; this.longitude = pos.coords.longitude; },
                () => { /* denied: leave blank */ },
                { enableHighAccuracy: false, timeout: 8000, maximumAge: 300000 }
            );
        }
        // brief loader on first paint
        // eslint-disable-next-line @lwc/lwc/no-async-operation
        window.setTimeout(() => { this.loading = false; }, 700);
    }

    get sscCount() { return this.sscFiles.length; }
    get hscCount() { return this.hscFiles.length; }
    get showFullPage() { return this.fullPageUrl && !this.done; }
    get showLoader() { return this.loading || this.submitting; }
    get loaderText() { return this.submitting ? 'Submitting your application...' : 'Loading...'; }

    openFullPage() { if (this.fullPageUrl) { window.open(this.fullPageUrl, '_blank'); } }

    handleSsc(event) { this.readInto(event, 'ssc'); }
    handleHsc(event) { this.readInto(event, 'hsc'); }

    readInto(event, which) {
        this.error = '';
        const list = [...event.target.files];
        for (const f of list) {
            const ext = f.name.split('.').pop().toLowerCase();
            if (!ALLOWED.includes(ext)) { this.error = `${f.name}: only PDF, JPG or PNG allowed.`; return; }
            if (f.size > MAX_MB * 1024 * 1024) { this.error = `${f.name}: larger than ${MAX_MB} MB.`; return; }
        }
        Promise.all(list.map((f) => this.toBase64(f)))
            .then((res) => { if (which === 'ssc') { this.sscFiles = res; } else { this.hscFiles = res; } })
            .catch(() => { this.error = 'Could not read the files. Please try again.'; });
    }

    toBase64(file) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = () => resolve({ fileName: file.name, base64: reader.result.split(',')[1] });
            reader.onerror = reject;
            reader.readAsDataURL(file);
        });
    }

    buildForm() {
        const f = {};
        this.template.querySelectorAll('[data-field]').forEach((el) => {
            const key = el.dataset.field;
            if (el.type === 'checkbox') { f[key] = el.checked; }
            else if (el.type === 'number') { f[key] = (el.value === '' || el.value == null) ? null : parseFloat(el.value); }
            else { f[key] = el.value ? String(el.value).trim() : ''; }
        });
        f.latitude = this.latitude;
        f.longitude = this.longitude;
        return f;
    }

    validate(f) {
        const required = [
            ['firstName', 'First Name'], ['lastName', 'Last Name'], ['email', 'Email'],
            ['phone', 'Phone'], ['address', 'Address'], ['pincode', 'Pincode'],
            ['sscPercentage', 'SSC %'], ['hscPercentage', 'HSC %']
        ];
        for (const [k, label] of required) {
            const v = f[k];
            if (v === null || v === undefined || String(v).trim() === '') return `${label} is required.`;
        }
        if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(f.email)) return 'Enter a valid email address.';
        if (!/^\d{10}$/.test(String(f.phone))) return 'Phone must be exactly 10 digits.';
        if (!/^\d{6}$/.test(String(f.pincode))) return 'Pincode must be exactly 6 digits.';
        const ssc = Number(f.sscPercentage), hsc = Number(f.hscPercentage);
        if (isNaN(ssc) || ssc < 0 || ssc > 100) return 'SSC % must be between 0 and 100.';
        if (isNaN(hsc) || hsc < 0 || hsc > 100) return 'HSC % must be between 0 and 100.';
        if (!f.consent) return 'Please tick the consent box.';
        if (this.sscFiles.length < 1) return 'Please upload at least one SSC document.';
        if (this.hscFiles.length < 1) return 'Please upload at least one HSC (12th) document.';
        return '';
    }

    async handleSubmit() {
        const form = this.buildForm();
        const err = this.validate(form);
        if (err) {
            this.error = err;
            this.template.querySelectorAll('lightning-input, lightning-textarea')
                .forEach((i) => { if (i.reportValidity) { i.reportValidity(); } });
            return;
        }
        this.error = '';
        this.submitting = true;
        try {
            const recordId = await submitApplication({
                applicantJson: JSON.stringify(form),
                sscFilesJson: JSON.stringify(this.sscFiles),
                hscFilesJson: JSON.stringify(this.hscFiles)
            });
            console.log('StudentOnboarding: SUCCESS, Applicant Id =', recordId);
            this.done = true;
        } catch (e) {
            // Show and log the REAL error so we can see the exact cause.
            console.error('StudentOnboarding: SUBMIT ERROR (full) =', JSON.stringify(e));
            const msg =
                (e && e.body && e.body.message) ? e.body.message :
                (e && e.body && e.body.pageErrors && e.body.pageErrors.length) ? e.body.pageErrors[0].message :
                (e && e.message) ? e.message : 'Submission failed. Please try again.';
            console.error('StudentOnboarding: SUBMIT ERROR (message) =', msg);
            this.error = msg;
        } finally {
            this.submitting = false;
        }
    }
}
